-- main.lua

require('scripts.main.main')